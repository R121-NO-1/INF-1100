#ifndef OPPGAVER_H
//opprettet header fil 
#define OPPGAVER_H

void oblig2_1();
void oblig2_2();
void oblig2_3(); //funksjoner deklarert 
void oblig2_4();
void oblig2_5();
void oblig2_6();


#endif