//run alt her
#include <stdio.h>
#include <stdbool.h>

void main(){

    while (true){
        //jeg vet ikke hvordan å lage et "test fil.." :C

    }
}