#include <stdio.h>

int main() {
    printf("Hallo verden! \n");
}