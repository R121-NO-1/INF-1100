// #include libs
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// #include headers
#include "lexer_preprocessor.h"



typedef enum
{ // grouping and defining the type of variables within the following struct
  ITEM_INT,
  ITEM_STRING
} ItemType;


/* */
typedef struct stackElement
{
  ItemType type;
  union
  { // defined on page 29 effective C by robert seacord
    int number;
    char *string;
  } value;
} StackItemType;

/*define the stuct and its values , this means what values it holds*/
typedef struct stack
{                       // different variables existent within the stack
  StackItemType array[MAXWORDS]; // dynamic array system for the stack
  int maxSize;          // maximum size of manipulatable stack
  int top;              // top element index nr
} Stack;


// define stack items

//declare every single function.

/*intialize function allows us to set the starting variables for now */
void initialize(Stack *s);

/* this function checks whether there it is empty, it returns 1 when true and and 0 when its false */
int isEmpty(Stack *s);

int isFull(Stack *s);

/* basic manipulative function, this manipulates the stack and allows us to exert actions onto the stack, in this case allows us to push or rather put items into the dynamic array*/
void push(Stack *s, StackItemType value);

/* basic manipulative function, this manipulates the stack and allows us to exert actions onto the stack, in this case "removes a stack" then allows us to write "in" (over) its place */
StackItemType pop(Stack *s);

/* Adds the x and y variables together if they are integers and not strings. then pushes the Result onto the stack */
void op_add(Stack *s);
/*subtracts x by y then pushes the result*/
void op_sub(Stack *s);
/*finds the difference by dividing  x by y, however if the y value is 0 then error prints out then pushes the result*/
void op_div(Stack *s);
/*Multiplies the x into the y variable if both are integers, if not prints "invalid error code 1 only with integers possible"*/
void op_mult(Stack *s);
/**/
void op_mod(Stack *s);
/**/
void op_is_equal(Stack *s);
/**/
void op_is_greater_than(Stack *s);
/**/
void op_newline(Stack *s);
/**/
void op_print(Stack *s);
/**/
void op_dup(Stack *s);
/**/
void op_swap(Stack *s);
/**/
char** op_cjump(Stack *s,char** pc );





char **tokens; //

void initialize(Stack *s)
{ // defining parameters for intialize
  // s->array = (int *)malloc(maxSize * sizeof(int)); // set the memory requried for the array
  s->top = -1; // makes index to empty
  s->maxSize = MAXWORDS;
}

// base functions

int isEmpty(Stack *s)
{                   // checks if the stack is empty,
  if (s->top == -1)
  // if top variable is equivalent to -1 it is empty

  // if top  our element turns out to be -1
  {
    return 1; // returns empty

    // if top index isnt -1
  }
  else
    return 0;
}
/*basic manipulative function, this checks whether the stack is full, and allows us to make sure not to fill the stack past its level*/
int isFull(Stack *s)            // if the stack is full, true, else false.
{                               // returns true if the stack is full otherwise returns false
  if (s->top >= s->maxSize - 1) // if topsize is equivalent to 4 or more, then return true, this means the stack is full
  {                             // since its [0,1,2,3,4] that will be a total of 5 in the stack and thus full
    return 1;                   // returns true
  } //      ##unsure if return works as it should try testing
    // else return false
  return 0;
}

// manipulative functions

void push(Stack *s, StackItemType value)
{ // checks if stack is full, if not push a stack ontop
  if (isFull(s))
  { // checks if overflow
    printf("Overflow Error \n");
    return;
  }
  else //execute main part function 
  {
    s->top++; // increment top
    s->array[s->top] = value; // accesses the element in the array 
  }
}
/* */
StackItemType pop(Stack *s)
{                 // removes the top most element of the stack
  if (isEmpty(s)) // if the stack is empty then  print nothing to remove,
  {
    printf("Stack underflow Error \n"); // nothing to remove from stack
    StackItemType error = {.type = ITEM_INT,  .value.number = 0};
    return error;
  }
  else
  {
    StackItemType tmp = s->array[s->top];
    s->top--;
    return tmp;
    // if pop then save stack in empty variable and decrement top.
  }

  // return top element then decrement pointer by 1
}

void op_add(Stack *s) // +
{
  StackItemType y = pop(s);
  StackItemType x = pop(s);

  if (y.type == ITEM_INT && x.type == ITEM_INT)
  {
    // if this then do that, otherwise dont do that and type error?
    StackItemType result = {.type = ITEM_INT, .value.number = x.value.number + y.value.number};
    push(s, result);
  }
  else
  {
    printf("Invalid, Error Code 1, only with integers possible.");
  }
  return; // exit?
}


// subtraction
/*  */
void op_sub(Stack *s)
{
  StackItemType y = pop(s);
  StackItemType x = pop(s);
  // if this then do that, otherwise dont do that and type error?
  if (y.type == ITEM_INT && x.type == ITEM_INT)
  {
    // if this then do that, otherwise dont do that and type error?
    StackItemType result = {.type = ITEM_INT, .value.number = x.value.number - y.value.number};
    push(s, result);
  }
  else
  {
    printf("Invalid, Error Code 1, only with integers possible.");
  }
}

/* */
void op_div(Stack *s)
{
  StackItemType y = pop(s);
  StackItemType x = pop(s);
  // if this then do that, otherwise dont do that and type error?

  if (y.value.number != 0)
  {
    // if this then do that, otherwise dont do that and type error?
    StackItemType result = {.type = ITEM_INT, .value.number = x.value.number / y.value.number};
    push(s, result);
  }
  else if (y.value.number == 0)
  {
    printf("Error this number is divided by 0");
  }

  else
  {
    printf("Invalid, Error Code 1, only with integers possible.");
  }
  // if  b == 0 then type error divison by 0 and then return/exit?
}

/*  */
void op_mult(Stack *s)
{
  StackItemType y = pop(s);
  StackItemType x = pop(s);
  // if this then do that, otherwise dont do that and type error?
  if (y.type == ITEM_INT && x.type == ITEM_INT)
  {
    // if this then do that, otherwise dont do that and type error?
    StackItemType result = {.type = ITEM_INT, .value.number = x.value.number * y.value.number};
    push(s, result);
  }
  else
  {
    printf("Invalid, Error Code 1, only with integers possible.");
  }
}

/* `.mod` pops two numbers from the stack and pushes the remainder of the second
  divided by the first.
*/
void op_mod(Stack *s)
{
  StackItemType y = pop(s);
  StackItemType x = pop(s);

  if (y.value.number != 0)
  {
    StackItemType result = {
        .type = ITEM_INT, .value.number = (x.value.number % y.value.number)};
    push(s, result);
  }
  else
    printf("Division by zero");
}

void op_is_equal(Stack *s) // ==
{
  StackItemType y = pop(s);
  StackItemType x = pop(s);

  if (y.value.number == x.value.number)
  {
    StackItemType result = {.type = ITEM_INT, .value.number = 1}; // if equal then true
    push(s, result);
  }
  else
  {
    StackItemType result = {.type = ITEM_INT, .value.number = 0}; // if not equal then untrue
    push(s, result);
  }
}

void op_is_greater_than(Stack *s) //  x > z
{
  StackItemType y = pop(s);
  StackItemType x = pop(s);
  if (x.value.number > y.value.number)
  {
    StackItemType result = {.type = ITEM_INT, .value.number = 1}; // true
    push(s, result);
  }
  else
  {
    StackItemType result = {.type = ITEM_INT, .value.number = 0}; // false
    push(s, result);
  }
}

void op_newline(Stack *s) // newline
{
  printf("\n");
}

void op_print(Stack *s)
{
  StackItemType tmp_top = pop(s);
  if (tmp_top.type == ITEM_STRING)
  {
    printf("%s", tmp_top.value.string);
  }
  else
  {
    printf("%d", tmp_top.value.number);
  }
}

void op_dup(Stack *s){
  StackItemType dupTOP; //temp variable
  dupTOP = s->array[s->top]; //set temp variable equivalent to top of the stack
push(s, dupTOP); //push top to "duplicate"
}


void op_swap(Stack *s)
{
  StackItemType tmp1;
  StackItemType tmp2;
  
  tmp1 = pop(s);  //first top that gets popped 
  tmp2 = pop(s); //second top that gets popped

push (s, tmp1);
push (s, tmp2);

}
/* 
### Control flow operations
* `.cjump` pops two numbers off the stack. if the second number is not `0` the
  program jumps by as many words as the first number indicates. eg. in 
  `1 -3 .cjump` the number `1` indicates that a jump should happen and the
  number `-3` indicates that the program should jump three words back. If the
  program for instance is `... 5 6 .* 1 -3 .cjump` we will jump back to the
  word `.*`.
  */
char** op_cjump(Stack *s,char** pc ){ //only allows input of integers
  int primary = pop(s).value.number; //primary number 
  int secondary = pop(s).value.number; //secondary number

  if (secondary != 0){
    pc = pc + primary;

    pc--;
  }
  return pc; //possible error

}

int main(int argc, char **argv)
{

  if (argc < 2)
  {
    printf("no program supplied\n");
    return 0;
  }

  // program is an array of strings; the end of the program is signified by a
  // NULL pointer.
  tokens = load_program(argv[1]);

  Stack *stack = malloc(sizeof(Stack));
  initialize(stack);

  

  for (char **pc = tokens; *pc != NULL; pc++)
  {

    // printf("program[%i]: %s\n", (int)(pc - tokens), *pc);

    if (*pc[0] == '.')
    {
      if (strcmp(*pc, ".+") == 0)
      {
        op_add(stack);
      }
      else if (strcmp(*pc, ".-") == 0)
      {
        op_sub(stack);
      }
      else if (strcmp(*pc, ".*") == 0)
      {
        op_mult(stack);
      }
      else if (strcmp(*pc, "./") == 0)
      {
        op_div(stack);
      }
      else if (strcmp(*pc, ".mod") == 0)
      {
        op_mod(stack);
      }
      else if (strcmp(*pc, ".=?") == 0)
      {
        op_is_equal(stack);
      }
      else if (strcmp(*pc, ".>?") == 0)
      {
        op_is_greater_than(stack);
      }
      else if (strcmp(*pc, ".newline") == 0)
      {
        op_newline(stack);
      }
      else if (strcmp(*pc, ".print") == 0)
      {
        op_print(stack);
      } 

      else if (strcmp(*pc, ".cjump") == 0)
      {
        pc = op_cjump(stack,pc);
      }
      else if (strcmp(*pc,".dup") == 0)
      {
        op_dup(stack);
      } else if (strcmp(*pc,".swap")== 0){
        op_swap(stack);
      }
      

    }
    else if (*pc[0] != '.')
    {
      if (*pc[0] == '~')
      {
        StackItemType tmp = {.type = ITEM_STRING, .value.string = *pc};
        push(stack, tmp);
      }
      else
      {
        StackItemType tmp = {.type = ITEM_INT, .value.number = atoi(*pc)};
        push(stack, tmp);
      }
    }
    else
    {
      printf("Unknown operator used.");
    }
  
   //free memory before exiting for memory leak management.
  //release allocated memory
  
  }
  return 0;

 
}
