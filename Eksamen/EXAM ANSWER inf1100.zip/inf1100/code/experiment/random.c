
// #include libs
#include <stdio.h>



// kappløp TO BIG ASS NUMBER 


int main()
{
for (int i=0; i<=40000000;i++){
    printf("%d \n", i);
    //1 m 29,602 seconds

}
    
}


