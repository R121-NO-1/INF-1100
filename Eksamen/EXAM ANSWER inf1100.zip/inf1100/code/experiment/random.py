## count to big number 40 million

for i in range(1,40000001):
    print(i)
    ##1 minute 40,517 seconds